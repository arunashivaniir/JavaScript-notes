const decreaseBtn=document.getElementById("decB");
const resetBtn=document.getElementById("resB");
const increaseBtn=document.getElementById("incB");
const countLabel=document.getElementById("countL");
let count=0;

increaseBtn.onclick=function(){
    count++;
    countLabel.textContent=count;
}

decreaseBtn.onclick=function(){
    count--;
    countLabel.textContent=count;
}

resetBtn.onclick=function(){
    count=0;
    countLabel.textContent=count;
}